# AutomationTesting_Amazon_ST_005
Virtual internship on automation testing with smartInternz in collaboration with AICTC and powered by Katalon.
