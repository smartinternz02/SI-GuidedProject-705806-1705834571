<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_All Departments        Arts  Crafts _135c92</name>
   <tag></tag>
   <elementGuidId>1d73428c-028d-4ef8-8d6e-44814e096e49</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>5da6b8b8-6af4-4232-8ab6-951dff8648ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>1398f90b-6aea-448b-aeb6-fa54edcf394b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>67e0d2d9-d3f3-4636-832b-3571e38c48c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>k+fyIAyB82R9jVEmroQ0OWwSW3A=</value>
      <webElementGuid>de96685e-e4d5-497b-ac67-82e207eacf41</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>61c1a4cc-7ac7-4e1d-ba07-7ce3b8e94997</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>5dba033f-b7c3-4fd8-9658-f6644d9dce24</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>ea71e4d2-1a93-49c9-b7a2-d965d8a5974c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>72e1d382-1a04-47ad-a5da-76e6d9198d31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>5ef34079-7eca-4e97-b5a3-cbd83ea4ea5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys' Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls' Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men's Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women's Fashion
    </value>
      <webElementGuid>93da3002-43c5-445a-bd57-8e655daf988b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>9811255e-2b81-4b21-a508-d3da7ca40485</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>d24c39a9-482b-4eef-81b1-1880a9741e4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>9db40306-8419-432a-b1a7-f351e14b024b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>0b403de0-6a57-4123-bae2-90dbdf232495</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;) or . = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;))]</value>
      <webElementGuid>f0766337-a3ad-4f96-b877-6536b383ae47</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
